#include <stdint.h>
#include <stddef.h>
void duole_decode_words(uint32_t *v,size_t n,const uint32_t *k){
 if(n<2)return;
 uint32_t y=v[0],z,e,delta=0x9e3779b9U,sum=(6U+52U/(uint32_t)n)*delta;
 while(sum){
  e=(sum>>2)&3U;
  for(size_t p=n-1;p>0;p--){
   z=v[p-1];
   uint32_t mx=(((z>>5)^(y<<2))+((y>>3)^(z<<4)))^((sum^y)+(k[(p&3)^e]^z));
   y=v[p]-=mx;
  }
  z=v[n-1];
  uint32_t mx=(((z>>5)^(y<<2))+((y>>3)^(z<<4)))^((sum^y)+(k[e]^z));
  y=v[0]-=mx;sum-=delta;
 }
}
