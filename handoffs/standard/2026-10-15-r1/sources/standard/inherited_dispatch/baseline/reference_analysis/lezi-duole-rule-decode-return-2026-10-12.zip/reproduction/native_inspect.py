import sys,struct,subprocess,json,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'deps'))
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
ROOT=Path(__file__).parent
LIB=ROOT/'extracted/lib/arm64-v8a/libduolechess.so'
blob=LIB.read_bytes()
stream=LIB.open('rb'); elf=ELFFile(stream)
symbols=list(elf.get_section_by_name('.dynsym').iter_symbols())
names=subprocess.run(['c++filt'],input='\n'.join(s.name for s in symbols),capture_output=True,text=True,check=True).stdout.splitlines()
syms=[{'name':n,'raw':s.name,'addr':s['st_value'],'size':s['st_size'],'type':s['st_info']['type']} for s,n in zip(symbols,names)]
addrnames={s['addr']:s['name'] for s in syms if s['addr']}
got={}
for sec in elf.iter_sections():
 if sec['sh_type']=='SHT_RELA':
  for rel in sec.iter_relocations():
   idx=rel['r_info_sym']
   if idx and idx<len(syms): got[rel['r_offset']]=syms[idx]['name']
plt=elf.get_section_by_name('.plt'); relplt=elf.get_section_by_name('.rela.plt')
if plt and relplt:
 for i,rel in enumerate(relplt.iter_relocations()): addrnames[plt['sh_addr']+32+16*i]=syms[rel['r_info_sym']]['name']+' [PLT]'
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN); md.detail=True
def read(addr,size):
 for seg in elf.iter_segments():
  if seg['p_type']=='PT_LOAD' and seg['p_vaddr']<=addr<seg['p_vaddr']+seg['p_filesz']:
   off=seg['p_offset']+addr-seg['p_vaddr'];return blob[off:off+size]
 return b''
def cstr(addr):
 b=read(addr,512);return b.split(b'\0')[0].decode('utf-8','replace')
def owner(addr):
 for s in syms:
  if s['size'] and s['addr']<=addr<s['addr']+s['size']: return s['name']
 return '?'
def disasm(s):
 lines=[f"FUNCTION {s['name']} @ {s['addr']:#x} size {s['size']}"]
 known={}
 for ins in md.disasm(read(s['addr'],s['size']),s['addr']):
  note=''; o=ins.operands
  if ins.mnemonic=='adrp' and len(o)==2: known[ins.reg_name(o[0].reg)]=o[1].imm
  elif ins.mnemonic=='add' and len(o)==3 and o[2].type==2:
   src=ins.reg_name(o[1].reg)
   if src in known:
    val=known[src]+o[2].imm;known[ins.reg_name(o[0].reg)]=val
    if val in addrnames: note=addrnames[val]
    else:
     st=cstr(val)
     if st and len(st)>2 and all(32<=ord(c)<127 for c in st[:20]): note=repr(st[:160])
  elif ins.mnemonic.startswith('ldr') and len(o)>1 and o[1].type==3 and not o[1].mem.index:
   rn=ins.reg_name(o[1].mem.base)
   if rn in known:
    val=known[rn]+o[1].mem.disp
    if val in got: note='GOT '+got[val]
  if ins.mnemonic in ('bl','b') and o and o[0].type==2: note=addrnames.get(o[0].imm,note)
  lines.append(f'{ins.address:08x}: {ins.bytes.hex()} {ins.mnemonic:8} {ins.op_str}'+(' ; '+note if note else ''))
  keep=None
  if o and o[0].type==1 and (ins.mnemonic=='adrp' or (ins.mnemonic=='add' and len(o)==3 and o[2].type==2 and ins.reg_name(o[1].reg) in known)):
   keep=ins.reg_name(o[0].reg)
  for reg in ins.regs_access()[1]:
   rn=ins.reg_name(reg)
   if rn!=keep:
    known.pop(rn,None)
    if rn.startswith('w'):known.pop('x'+rn[1:],None)
  if ins.mnemonic=='bl':
   for i in range(19):known.pop('x'+str(i),None)
  if ins.mnemonic in ('b','ret') or ins.mnemonic.startswith('b.') or ins.mnemonic in ('cbz','cbnz','tbz','tbnz'):
   known.clear()
 return '\n'.join(lines)+'\n'
def calls_to(targets):
 targets=set(targets)
 for sec in elf.iter_sections():
  if not sec['sh_flags']&4:continue
  b=sec.data();start=sec['sh_addr']
  for i in range(0,len(b)-3,4):
   word=struct.unpack_from('<I',b,i)[0]
   if word&0xfc000000 not in (0x94000000,0x14000000):continue
   imm=word&0x3ffffff
   if imm&0x2000000:imm-=0x4000000
   dest=start+i+imm*4
   if dest in targets:yield {'at':hex(start+i),'target':hex(dest),'caller':owner(start+i),'kind':'bl' if word&0xfc000000==0x94000000 else 'b'}
if __name__=='__main__':
 out=ROOT/'disasm';out.mkdir(exist_ok=True)
 patterns=sys.argv[1:]
 selected=[s for s in syms if s['type']=='STT_FUNC' and s['size'] and any(p in s['name'] for p in patterns)]
 for s in selected:
  p=out/f"{s['addr']:x}.txt";p.write_text(disasm(s));print(json.dumps({**s,'file':str(p)},ensure_ascii=False))
