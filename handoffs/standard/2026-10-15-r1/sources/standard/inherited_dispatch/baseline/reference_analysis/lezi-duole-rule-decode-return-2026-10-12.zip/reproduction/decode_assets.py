from pathlib import Path
import sys,zipfile,struct,json,hashlib
sys.path.insert(0,str(Path(__file__).parent))
import native_inspect as n
ROOT=Path(__file__).parent
def xxtea(data,key):
 if len(data)%4:return None
 v=list(struct.unpack('<'+'I'*(len(data)//4),data)); k=list(struct.unpack('<4I',key.ljust(16,b'\0')[:16])); ln=len(v)
 if ln<2:return None
 delta=0x9e3779b9;total=((6+52//ln)*delta)&0xffffffff;y=v[0]
 while total:
  e=(total>>2)&3
  for p in range(ln-1,0,-1):
   z=v[p-1];mx=(((z>>5)^(y<<2))+((y>>3)^(z<<4)))^((total^y)+(k[(p&3)^e]^z))
   y=v[p]=(v[p]-mx)&0xffffffff
  z=v[-1];mx=(((z>>5)^(y<<2))+((y>>3)^(z<<4)))^((total^y)+(k[e]^z))
  y=v[0]=(v[0]-mx)&0xffffffff;total=(total-delta)&0xffffffff
 length=v[-1]
 if not ((ln-1)*4-3<=length<=(ln-1)*4):return None
 return struct.pack('<'+'I'*(ln-1),*v[:-1])[:length]
def main():
 out=ROOT/'decoded';out.mkdir(exist_ok=True)
 password=n.cstr(0x182db86).encode()
 rows=[]
 with zipfile.ZipFile(ROOT/'extracted/assets/res/dcresource.zip') as z:
  for e in z.infolist():
   if e.filename.startswith('bigImage/') and 'rule' in e.filename:
    b=z.read(e,pwd=password);p=out/'rules'/Path(e.filename).name;p.parent.mkdir(exist_ok=True);p.write_bytes(b)
    rows.append({'source':e.filename,'output':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'crc_validated':True})
 (ROOT/'decoded-rule-index.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 print('RULE IMAGES DECODED',len(rows))
 key=n.cstr(0x18309f0).encode();scripts=list((ROOT/'extracted/assets/src').rglob('*.luac'))
 result=[]
 for f in scripts[:3]:
  raw=f.read_bytes();b=xxtea(raw[8:],key)
  if b is None:print('DECODE FAILED',f.name);continue
  p=out/f.name;p.write_bytes(b);result.append({'file':f.name,'bytes':len(b),'header':b[:24].hex()})
 print('SCRIPT TEST',json.dumps(result))
if __name__=='__main__':main()
