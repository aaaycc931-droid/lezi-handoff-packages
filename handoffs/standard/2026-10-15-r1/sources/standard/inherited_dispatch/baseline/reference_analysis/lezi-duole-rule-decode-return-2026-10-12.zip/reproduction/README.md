# 本地静态复验

需要用户提供的原 APK（SHA-256见上级RULE_FINDINGS.json），Python 3、C 编译器、pyelftools 0.33、capstone 5.0.9。代码只解析文件，不启动APK或访问游戏服务。

1. 创建独立工作目录，将APK中的 lib/arm64-v8a/libduolechess.so、assets/src目录、assets/res/dcresource.zip解压到 extracted/ 下，并保留路径。
2. 在工作目录下将 pyelftools、capstone 安装到 deps/（例如python3 -m pip install --target deps pyelftools==0.33 capstone==5.0.9），安装后可断网。
3. 将本目录四个分析源码放在工作目录根部。执行 python3 decode_assets.py，得到规则图和前三个Lua解码样本。
4. 执行 cc -shared -fPIC -O2 xxtea_decode.c -o xxtea_decode.so，再执行 python3 decode_scripts.py，核对631份合法UTF-8及0错误，前三份与Python实现一致。
5. 执行 python3 native_inspect.py 'JieQi::repeatRule(' 'JieQi::CJEngine::getResult(bool)' 等，核对原始字节、函数地址和条件分支。地址为ELF虚拟地址，不能直接当文件偏移。
6. 比对图像和解码脚本SHA-256索引、Lua摘录行号及native函数原始机器码SHA-256。

反汇编末尾注解只作定位辅助；机器码和分支条件才是证据。脚本参数由本APK原生初始化/解包函数确定，其他版本的地址或参数可能不同。

本包没有把服务器代码补成客户端代码，也没有动态实测对局。函数存在、数字存在与目标模式实际线上裁判分别记录。
