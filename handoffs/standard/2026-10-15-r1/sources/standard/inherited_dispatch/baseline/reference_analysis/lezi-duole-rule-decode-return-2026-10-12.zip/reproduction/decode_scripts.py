import ctypes,struct,json,hashlib
from pathlib import Path
from decode_assets import xxtea
import native_inspect as n
root=Path(__file__).parent
lib=ctypes.CDLL(str(root/'xxtea_decode.so'))
lib.duole_decode_words.argtypes=[ctypes.POINTER(ctypes.c_uint32),ctypes.c_size_t,ctypes.POINTER(ctypes.c_uint32)]
key=n.cstr(0x18309f0).encode();ka=(ctypes.c_uint32*4).from_buffer_copy(key.ljust(16,b'\0')[:16])
out=root/'decoded/scripts';out.mkdir(exist_ok=True)
rows=[];errors=[]
for i,f in enumerate((root/'extracted/assets/src').rglob('*.luac')):
 raw=f.read_bytes();data=raw[8:];count=len(data)//4
 va=(ctypes.c_uint32*count).from_buffer_copy(data)
 lib.duole_decode_words(va,count,ka)
 length=va[-1]
 if not (len(data)-7<=length<=len(data)-4):errors.append(f.name);continue
 decoded=bytes(va)[:length]
 if i<3:assert decoded==xxtea(data,key)
 try:text=decoded.decode('utf-8')
 except UnicodeDecodeError:errors.append(f.name);continue
 p=out/(f.stem+'.lua');p.write_text(text)
 rows.append({'input':f.name,'output':p.name,'bytes':len(decoded),'sha256':hashlib.sha256(decoded).hexdigest()})
(root/'decoded-script-index.json').write_text(json.dumps({'decoded':rows,'errors':errors},indent=2))
print('Decoded UTF-8 Lua:',len(rows),'Errors:',len(errors))
