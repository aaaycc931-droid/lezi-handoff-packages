# 多乐揭棋乱斗规则解码与主线审查｜2026-10-12

## 已完成的结果

已实际解开本次用户提供 APK 的加密规则资源和全部 631 个脚本。它们是 UTF-8 Lua 源文本，而不是仍需反编译的 Lua 字节码。七张“揭棋乱斗”教程图已读取；乱斗场景到 setMelee(true)、Lua 绑定、原生开关的映射已建立。此前外部报告“脚本未解密、资源未解密、界面对应待证”这三项限制已被本轮证据更新。

本轮恢复的是本安装包内的教程和客户端实现。联网的循环裁判算法仍不在已取得的客户端代码中；不能把本地阈值宣布为已经实测的服务器规则。未运行 APK、未连接多乐服务、未消费游戏币，未修改乐子象棋引擎或 GitHub。

## 固定样本与验证

- APK：多乐中国象棋.apk；包名 com.duole.chinachess.nearme.gamecenter。
- 版本：5.1.19，versionCode 5011900；资源配置 sourceversion=20260827200421。
- APK 实测大小 117950144 bytes；SHA-256：95574ad0a5d423f26238cb6f345914fec23189c2cb9d2631d136d1e0abb2df48，与支线报告一致。
- 核心库：lib/arm64-v8a/libduolechess.so，32846720 bytes；SHA-256 见 RULE_FINDINGS.json。
- 从 StaticController::unzipGameResource 追踪资源解包参数，成功读取 15 张规则图片，读取时 ZIP CRC 通过。其中七张属于乱斗教程。
- 从 luahelper::LuaHelper::initialize → LuaStack::setXXTEAKeyAndSign → luaLoadBuffer → xxtea_decrypt 追踪脚本解码。631/631 文件得到合法 UTF-8 Lua 文本；前三个文件的 Python 与独立 C 实现逐字节一致。
- 本地函数原始字节与反汇编、选定 Lua 行号摘录、图像哈希和复现脚本随包保存。没有把全部第三方客户端代码或原始 APK 再复制进回传包。

## 可以直接核实的乱斗基础规则

| 内容 | 安装包教程证据 |
| --- | --- |
| 将帅除外，双方其他棋子混在一起随机打乱摆放 | rules/bg_rule_darkchess_luandou1.png |
| 双方都可能翻出对方明子 | rules/bg_rule_darkchess_luandou2.png |
| 双方都可以吃自己的暗子 | rules/bg_rule_darkchess_luandou3.png |
| 暗子第一步按象棋起始位置的规则行动 | rules/bg_rule_darkchess_luandou4.png |
| 暗子第一步走完翻明，以后按真实棋种行动 | rules/bg_rule_darkchess_luandou5.png |
| 明士、象可以过河 | rules/bg_rule_darkchess_luandou6.png |
| 翻出对方棋子造成将军会直接结束游戏，图中称“伏杀” | rules/bg_rule_darkchess_luandou7.png |

Lua 场景枚举把 kSceneDarkMeleeOnlineGame 定为 44；该场景 onRegister 明确调用 setMelee(当前场景==乱斗场景)。原生 setMelee 将参数写入 bMeleeGame。图像选择面板在 type=2 时展示上述七张图，标题为“乱斗教程”。这些证据将图像、用户可见模式和原生模式连接起来。

这对应乐子现有的全局混洗揭棋，不能误记成双方各自混洗的半混乱模式。用户此前提供的“可吃己方暗子”和“自己揭出敌方棋子反将自己立即输”现有安装包内教程佐证。本项目英雄和畸变的例外不由多乐资料覆盖。

## 循环与和棋：已经定位到的本地实现

### 1. 本地引擎采用 120 个计数步及 400 个总步数的阈值

JieQi::repeatRule（0xa687d0）和 repeatRuleNoRepeat（0xa6af3c）均读取当前 StateInfo+0xb8 的计数，比较其是否大于 0x77，即至少 120；另一分支比较 Position+0x19f0 是否至少 0x190，即 400。分别返回原因 2 和 3。Lua 显示文案分别为“双方六十回合未吃子”“总步数达到二百回合”。

因此，本地代码恢复的是120计数步/60回合与400总步/200回合这两个阈值。120不能无条件简写为120次任意原始移动：do_move 的0xa6511c–0xa65144分支会在特定将军条件下调整该计数，双方对应计数达到第11次后抵消本次增长。捕获相关分支还会归零计数。完整的暗子揭示、特殊开局和计数交互不能只靠一个常量概括。

这些函数还检查无合法行动与将军位图。困毙和绝杀边界不能只按步数强行判和。

### 2. 普通重复局面默认参数为5，附压力检查

check_repeat_situation_rule（0xa6a7d8）的0xa6a8fc设置默认阈值5；开始计数为1，对历史状态key（StateInfo+0xc0）逐项比较，同侧历史每次向前追两个状态。达到次数时返回原因4。Lua 对应显示“局面重复5次”。

此路径还检查将军位图、getChasePieces以及历史中的合法攻击条件。因此不是“棋子位置第五次相同就不分情况判和”。棋盘、暗身份和状态key的完整组成，以及英雄状态如何进入我们自己的重复判定，仍需独立定义。

### 3. 长将/长捉存在6为基础的本地裁判路径

getResult(true) 调用 repeatRule(position,128,6)，后者依次进入 check_repeat_rule、check_repeat_asianrule_rule、check_repeat_situation_rule。普通与Melee路径共享这些函数；本轮检查的三个重复函数中没有发现直接读取 bMeleeGame 的分支。不过乱斗更新棋局和将军信息的方式本身有差异，这不等于两种模式全部裁判语义一致。

check_repeat_rule 的基础阈值为6，参与将军的棋子数被上限3截断，并与阈值相乘；代码包含互相长将原因5、长将禁着原因6。check_repeat_asianrule_rule 包含互相长捉原因7、长捉禁着原因8及将捉交替原因9。

这证明本地客户端存在完整的压力分类，而不是只有和棋。长捉目标保护、交换机会、交替压力及责任判定分支较复杂；本轮不把数字6当成所有情况的完整规格。

### 4. “禁着”在本地有拒绝行动路径

CJEngine::move 临时 do_move → repeatRule → undo_move，将原因6、7、8、9查表。原始表为(-5,0,-5,-5)：原因6、8、9返回-5，互相长捉原因7返回0。DCDarkEleeye::checkCanMove 把-5转换为返回2；Lua 在失败分支显示“长将长捉判负，已禁着”，并不进入成功行动分支。

所以，不能仅凭这句提示就认定用户点击禁着后立即完成整局败负。本地有明确的禁止行动机制，联网败负还可能走服务器结果路径。

## 为什么还不能宣布线上规则已全部还原

1. DCGameModel:getNeedCheckRepeat 对联网场景返回 false，包括乱斗场景。
2. 走子代码明确写明联网只检查能否走子、不检测长将长捉，收到走棋响应后才真正走棋。
3. DCDarkEleeye::getOnlineResult 向原生 getResult 传 false；虚表0x200已解析到 CJEngine::getResult(bool)。该路径走 repeatRuleNoRepeat，不调用客户端长将/长捉分类器。
4. 网络结束结果从 tableData.value.type 和 tableData.value.reson 填入，原因3显示“长将(长捉)判负”，原因14显示“伏杀”。这是结果解释，不是服务器算法。
5. 客户端存在相互冲突的旧文案：同一包的网络结果文本写“50回合没有吃子”；另一组显示文案、规则图和本地代码为60回合。不能用旧注释或文案替代线上当前阈值。
6. 七张乱斗教程没有直接写长将、长捉、重复局面及和棋次数。普通象棋规则图虽有相关内容，但没有证明它在乱斗规则界面中展示，不能直接当乱斗正式说明。

可准确报告的结果为：乱斗基础玩法已有客户端内置规则佐证；共享本地裁判的主要阈值、原因和禁着处理已追踪；线上完整裁判仍需要服务器实现或无消费的可控验证来源。APK自身不能提供缺失的服务器代码。

## 对乐子象棋主线的处理

- 普通象棋和半混乱揭棋继续以用户已选定、已截图的天天象棋对应模式为参考，不被多乐本地60回合自动替换。
- 全局混洗模式可借鉴本包已证实的基础玩法及本地循环裁判结构。是否采用60回合、200回合、5次和6为基础的条件，属于本项目规则选择与适配，不能标成“多乐线上已验证”。
- 半混乱H11-B的正式计数与时钟继续使用主线 CONF-HC-H11-B-20261012；多乐没有这套乐子英雄机制，本次分析不改其确认状态。
- 未改引擎、UI、GitHub、评分资格或产品开放状态；正式评分继续冻结。

复验入口见 reproduction/README.md。RULE_FINDINGS.json按证据类型区分规则图、解码Lua、原始机器码及尚缺失的服务器范围。

