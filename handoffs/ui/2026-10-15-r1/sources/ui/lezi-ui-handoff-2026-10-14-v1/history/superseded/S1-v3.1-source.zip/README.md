# 乐子象棋 S1-v3.1 局部修订源包

用户原话（2026-10-14 13:03:34 Asia/Shanghai）：开启按钮后的墨圈体积需要缩小15%。

当前候选仅修改四个开启状态实心墨圈，直径及两轴等比缩至S1-v3的85%；中心位置不变。关闭空心墨圈、文字、版式与未指定背景保持。页面内部原S1-v3标题依用户修改范围原样保留，文件版本为S1-v3.1，仍待明确审批。

source/是不可变S1-v3。layers/是实际栅格墨圈的原样提取和缩放层，没有重新绘制墨圈。background-layers/中旧墨圈遮住的底色是一次局部估计，不是恢复了不可见原始纸纹。

复现当前图使用node scripts/compose-from-layers.cjs，读取归档底层与缩放图层，不抹字、不修补、不整图生成。sharp由CODEX_PRIMARY_RUNTIME_NODE_MODULES解析。scripts/shrink-enabled-controls.cjs保留首次提取的方法证据，不应用于逐轮重新补底；后续参数调整复用固定底层与原墨圈图层。

保护验证使用verify_pixel_diff.py与evidence/edit-parameters.json、evidence/allowed-control-footprints.png；保护区差异0，母版SHA-256不变。像素证据与用户审美审批分开；运行、动效、触控和产品接入未验收。

