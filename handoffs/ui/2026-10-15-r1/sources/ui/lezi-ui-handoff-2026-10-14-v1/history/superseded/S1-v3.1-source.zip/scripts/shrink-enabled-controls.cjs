// User-authorized local edit: scale only four ON-state ink controls by 0.85.
// The source is immutable. Extract actual raster ink; never redraw it.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sharp = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/sharp');
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'source/lezi-settings-S1-v3.png');
const candidate = path.join(root, 'preview/lezi-settings-S1-v3_1.png');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const expected = 'f7d84d5ee2b86b2b958343f1a1456a24936b45747ab44ae0f38ff4bf65bb8e6a';
const scale = 0.85;
const controls = [
 {id:'regular_sound_on_ink', cx:355, cy:345},
 {id:'regular_haptic_on_ink', cx:355, cy:415},
 {id:'short_sound_on_ink', cx:733, cy:322},
 {id:'short_haptic_on_ink', cx:733, cy:391},
];
function lum(a,k) { return .2126*a[k]+.7152*a[k+1]+.0722*a[k+2]; }
function lanczos(t) {
 t=Math.abs(t);
 if(t<1e-10) return 1;
 if(t>=3) return 0;
 return Math.sin(Math.PI*t)*Math.sin(Math.PI*t/3)/(Math.PI*Math.PI*t*t/3);
}
(async()=>{
 for(const d of ['layers','background-layers','preview','evidence']) fs.mkdirSync(path.join(root,d),{recursive:true});
 const originalFile=fs.readFileSync(source);
 if(sha(originalFile)!==expected) throw new Error('Source identity mismatch');
 const {data,info}=await sharp(originalFile).ensureAlpha().raw().toBuffer({resolveWithObject:true});
 if(info.width!==1496 || info.height!==1051 || info.channels!==4) throw new Error('Unexpected source dimensions');
 const base=Buffer.from(data), result=Buffer.from(data), restored=Buffer.from(data);
 const allowed=Buffer.alloc(info.width*info.height);
 const items=[],regions=[];
 const w=61,h=61,n=w*h;
 for(const c of controls) {
  const x=c.cx-30,y=c.cy-30;
  const roi=Buffer.alloc(n*4), mask=new Uint8Array(n), queue=[];
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
   const p=j*w+i,k=((y+j)*info.width+x+i)*4;
   data.copy(roi,p*4,k,k+4);
  }
  // This isolated control ROI contains no labels or landscape strokes.
  // Grow only the connected ink component containing the control center.
  const seed=30*w+30;
  if(lum(roi,seed*4)>130) throw new Error('Expected a filled ON-state control');
  mask[seed]=1; queue.push(seed);
  for(let at=0;at<queue.length;at++){
   const p=queue[at],px=p%w,py=Math.floor(p/w);
   for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
    const ix=px+dx,iy=py+dy;
    if(ix<0||iy<0||ix>=w||iy>=h) continue;
    const q=iy*w+ix;
    if(!mask[q]&&lum(roi,q*4)<205){mask[q]=1;queue.push(q);}
   }
  }
  const erase=new Uint8Array(mask);
  for(let j=1;j<h-1;j++)for(let i=1;i<w-1;i++){
   if(!mask[j*w+i])continue;
   for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)erase[(j+dy)*w+i+dx]=1;
  }
  let minX=w,minY=h,maxX=-1,maxY=-1,footprint=0;
  for(let j=0;j<h;j++)for(let i=0;i<w;i++)if(erase[j*w+i]){
   minX=Math.min(minX,i); minY=Math.min(minY,j); maxX=Math.max(maxX,i); maxY=Math.max(maxY,j);footprint++;
  }
  if(minX<5||minY<5||maxX>w-6||maxY>h-6)throw new Error('Unexpected control footprint');
  // Once-only local estimate of paper hidden by ink, not recovery of original pixels.
  const paper=new Float64Array(n*3),sums=[0,0,0]; let count=0;
  for(let p=0;p<n;p++)if(!erase[p]){count++; for(let a=0;a<3;a++)sums[a]+=roi[p*4+a];}
  for(let p=0;p<n;p++)for(let a=0;a<3;a++)paper[p*3+a]=erase[p]?sums[a]/count:roi[p*4+a];
  for(let pass=0;pass<1400;pass++)for(let j=1;j<h-1;j++)for(let i=1;i<w-1;i++){
   const p=j*w+i;if(!erase[p])continue;
   for(let a=0;a<3;a++)paper[p*3+a]=(paper[(p-1)*3+a]+paper[(p+1)*3+a]+paper[(p-w)*3+a]+paper[(p+w)*3+a])/4;
  }
  const ink=Buffer.alloc(n*4);
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
   const p=j*w+i,k=((y+j)*info.width+x+i)*4;
   if(!erase[p])continue;
   for(let a=0;a<3;a++){base[k+a]=Math.round(paper[p*3+a]); ink[p*4+a]=roi[p*4+a];}
   ink[p*4+3]=255; allowed[(y+j)*info.width+x+i]=255;
  }
  const layer='layers/'+c.id+'-original.png';
  await sharp(ink,{raw:{width:w,height:h,channels:4}}).png().toFile(path.join(root,layer));
  // Geometric scale is exactly 0.85 around the original pixel center.
  // Downsampling uses Lanczos3 on premultiplied RGBA, without resizing the page.
  const small=Buffer.alloc(n*4);
  const support=3/scale;
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
   const sx=30+(i-30)/scale,sy=30+(j-30)/scale;
   let sumW=0,alpha=0,rgba=[0,0,0];
   for(let yy=Math.ceil(sy-support);yy<=Math.floor(sy+support);yy++){
    const wy=lanczos((yy-sy)*scale);
    for(let xx=Math.ceil(sx-support);xx<=Math.floor(sx+support);xx++){
     const weight=wy*lanczos((xx-sx)*scale);sumW+=weight;
     if(xx<0||yy<0||xx>=w||yy>=h)continue;
     const k=(yy*w+xx)*4,a=ink[k+3]/255;
     alpha+=weight*a;
     for(let ch=0;ch<3;ch++)rgba[ch]+=weight*a*ink[k+ch];
    }
   }
   const k=(j*w+i)*4;
   const a=Math.max(0,Math.min(1,alpha/sumW));
   small[k+3]=Math.round(a*255);
   if(small[k+3])for(let ch=0;ch<3;ch++)small[k+ch]=Math.max(0,Math.min(255,Math.round(rgba[ch]/alpha)));
  }
  const scaledLayer='layers/'+c.id+'-scale-085.png';
  await sharp(small,{raw:{width:w,height:h,channels:4}}).png().toFile(path.join(root,scaledLayer));
  items.push({...c,x,y,width:w,height:h,source_layer:layer,scaled_layer:scaledLayer,scale,
   hidden_background_estimated:true,estimated_pixel_count:footprint,
   geometric_center_shift:[0,0],original_ink_footprint_bounds:{x:x+minX,y:y+minY,width:maxX-minX+1,height:maxY-minY+1}});
  // Authorize only the old ink footprint and its necessary resampling fringe.
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
   const k=(j*w+i)*4;if(!small[k+3])continue;
   const gx=x+i,gy=y+j;
   if(i<minX-2||j<minY-2||i>maxX+2||j>maxY+2)throw new Error('Scaled ink escaped the authorized control region');
   allowed[gy*info.width+gx]=255;
  }
  regions.push({id:c.id,x:x+minX-2,y:y+minY-2,width:maxX-minX+5,height:maxY-minY+5});
 }
 base.copy(result);base.copy(restored);
 for(const c of items){
  const original=await sharp(path.join(root,c.source_layer)).raw().toBuffer();
  const scaled=await sharp(path.join(root,c.scaled_layer)).raw().toBuffer();
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
   const p=j*w+i,k=((c.y+j)*info.width+c.x+i)*4,s=p*4;
   if(original[s+3])for(let ch=0;ch<4;ch++)restored[k+ch]=original[s+ch];
   const a=scaled[s+3]/255;
   if(a)for(let ch=0;ch<3;ch++)result[k+ch]=Math.round(base[k+ch]*(1-a)+scaled[s+ch]*a);
  }
 }
 if(!restored.equals(data))throw new Error('Original extracted controls do not reconstruct the source exactly');
 await sharp(base,{raw:{width:info.width,height:info.height,channels:4}}).png().toFile(path.join(root,'background-layers/s1-v3-enabled-controls-removed-estimated.png'));
 await sharp(allowed,{raw:{width:info.width,height:info.height,channels:1}}).toColourspace('b-w').png().toFile(path.join(root,'evidence/allowed-control-footprints.png'));
 await sharp(result,{raw:{width:info.width,height:info.height,channels:4}}).png().toFile(candidate);
 let changed=0,outside=0;
 for(let p=0;p<info.width*info.height;p++){
  const k=p*4;if(data[k]===result[k]&&data[k+1]===result[k+1]&&data[k+2]===result[k+2]&&data[k+3]===result[k+3])continue;
  changed++;if(!allowed[p])outside++;
 }
 if(outside)throw new Error('Protected pixels changed');
 if(sha(fs.readFileSync(source))!==expected)throw new Error('Source changed');
 const params={schema:'lezi.s1_enabled_ink_local_resize.v1',version:'S1-v3.1',source_version:'S1-v3',
  source_sha256:expected,output_sha256:sha(fs.readFileSync(candidate)),width:info.width,height:info.height,
  authorized_by:'开启按钮后的墨圈体积需要缩小15%',scale_interpretation:'linear diameter and both axes are 85% of current; area is 72.25% of current',
  state_scope:'four filled ON controls only',closed_controls_unchanged:true,header_unchanged:true,
  text_unchanged:true,source_reconstruction_exact:true,source_unchanged:true,
  changed_pixels:changed,changed_pixels_outside_authorized_mask:outside,
  background_classification:'once-only local estimate under original ink footprints; hidden original paper cannot be recovered',
  controls:items,regions,allowed_mask:'evidence/allowed-control-footprints.png',
  background_layer:'background-layers/s1-v3-enabled-controls-removed-estimated.png',
  current_candidate:'preview/lezi-settings-S1-v3_1.png',approval:'pending_user_review',runtime_acceptance:'not_run'};
 fs.writeFileSync(path.join(root,'evidence/edit-parameters.json'),JSON.stringify(params,null,2)+'\n');
 console.log(JSON.stringify(params));
})().catch(e=>{console.error(e);process.exitCode=1;});

